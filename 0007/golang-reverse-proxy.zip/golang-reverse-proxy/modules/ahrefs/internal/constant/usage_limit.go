package constant

const ReportUsageLimit = 30
const ExportUsageLimit = 10

// single session will be 8 hours 8 minutes
const UsageLimitDuration = 8*60 + 8
