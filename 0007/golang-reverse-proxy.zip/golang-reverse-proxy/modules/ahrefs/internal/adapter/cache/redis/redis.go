package redis

var KeyPrefix = "ahx"
